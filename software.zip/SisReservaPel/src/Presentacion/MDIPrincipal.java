package Presentacion;




import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class MDIPrincipal extends JFrame {
	
	
  
	
	private JMenuBar miBarraMenu;
	
	private JMenu jmiMenuRegistros,jmiMenuOpciones,jmiMenuConsultas; 
	
	private JMenuItem jmItemCortes_de_cabello,jmItemReservas,jmItemVentas;
	

	private JMenuItem jmItemUsuarios,jmItemConsultasV;
	
	private  JDesktopPane 	jdpEscritorio;
	
	
	
	public MDIPrincipal () {
		
		
		
		setTitle("...:: sistema para reservaciones ::...");
		
		
		setSize(1100,700);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		

		
		ImageIcon immenuReg = new ImageIcon(getClass().getResource("/imagenes/imenuReg.png"));
		ImageIcon immenucon = new ImageIcon(getClass().getResource("/imagenes/immenucon.png"));
		ImageIcon immenuOp = new ImageIcon(getClass().getResource("/imagenes/MenuOpciones.png"));
		ImageIcon imtemCortesDeCabello = new ImageIcon(getClass().getResource("/imagenes/iconocorte.png"));
		ImageIcon imreservas = new ImageIcon(getClass().getResource("/imagenes/imreservas.png"));
		ImageIcon imventas = new ImageIcon(getClass().getResource("/imagenes/imventas.png"));
		ImageIcon imusuarios = new ImageIcon(getClass().getResource("/imagenes/imusuarios.png"));
		ImageIcon imiconsultasV = new ImageIcon(getClass().getResource("/imagenes/imiconsultasV.png"));
		
		
      //creando componentes 
		miBarraMenu =new JMenuBar();
		
		jmiMenuRegistros= new JMenu("registros");
		jmiMenuOpciones= new JMenu("Opciones");
		jmiMenuConsultas= new JMenu("Consultas");
		jmItemCortes_de_cabello= new JMenuItem("Cortes");
		jmItemReservas= new JMenuItem("Reservas");
		jmItemVentas= new JMenuItem("Ventas");
		jmItemUsuarios =new  JMenuItem("Usuarios");
		jmItemConsultasV   =new  JMenuItem("Consultas ventas");
		
		//asignar imagenes iconos
		
		jmiMenuRegistros.setIcon(immenuReg);
		jmiMenuOpciones.setIcon(immenuOp);
		jmiMenuConsultas.setIcon(immenucon);
		jmItemCortes_de_cabello.setIcon(imtemCortesDeCabello);
		jmItemReservas.setIcon(imreservas);
		jmItemVentas.setIcon(imventas);
		jmItemUsuarios.setIcon(imusuarios);
		jmItemConsultasV.setIcon(imiconsultasV );
		
		//agregando ventanas a la barra del menu 
		
		jmiMenuRegistros.add( jmItemCortes_de_cabello);
		jmiMenuRegistros.add( jmItemReservas);
		jmiMenuRegistros.add( jmItemVentas);
		
		jmiMenuConsultas.add( jmItemConsultasV);
		jmiMenuOpciones.add( jmItemUsuarios);
		
		
		miBarraMenu.add(jmiMenuRegistros);
		miBarraMenu.add(jmiMenuOpciones);
		miBarraMenu.add(jmiMenuConsultas);
		setJMenuBar(miBarraMenu);
		
		
		jdpEscritorio  = new JDesktopPane();
		
		
	
		getContentPane ().add(jdpEscritorio );
	
	
	jmItemUsuarios.addActionListener(new ActionListener(){
		
		public void actionPerformed(ActionEvent evt ) {
			
			jmItemUsuariosActionPerformed(evt);
		}

	});
	
	
	
	
	
	}
	
private void jmItemUsuariosActionPerformed(ActionEvent evt ) {
			
	FrmUsuarios misUsuarios =new FrmUsuarios();
	jdpEscritorio.add(misUsuarios);
	misUsuarios.show();
	
	
	}
	
	
	

}

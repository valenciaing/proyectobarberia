package Datos;

import java.awt.Image;

import javax.swing.ImageIcon;

import Presentacion.FrmLogin;
import Presentacion.FrmUsuarios;
import Presentacion.MDIPrincipal;

public class DPrincipal {

	public static void main(String[] args) {


		
		
	//FrmLogin miLogin = new FrmLogin();
	MDIPrincipal miPrincipal = new MDIPrincipal();
	  // miLogin.setVisible(true);	
		miPrincipal.setVisible(true);
	}

}

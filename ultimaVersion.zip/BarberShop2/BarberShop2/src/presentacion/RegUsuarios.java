package presentacion;

import conexion.Conexion;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.*;

public class RegUsuarios extends JFrame {

    private JLabel lblId, lblNombre, lblAparterno, lblAmaterno, lblFondo2;
    private JLabel lblUsuario, lblClave, lblConfirmarClave, lblPerfil;
    private JTextField txtId, txtaparterno, txtNombre, txtAmarterno;
    private JTextField txtUsuario;
    private JPasswordField txtClave, TxtConfirmaClave;
    private JComboBox<String> cmbperfil;
    private JButton btnRegistrar, btnCancelar;

    private String[] Perfil = { "Administrador", "Empleado" };

    public RegUsuarios() {
        setTitle("Registro Usuarios Nuevos");
        setSize(1200, 600);
        // Establecer el color de fondo oscuro
        getContentPane().setBackground(Color.BLACK);
        setLayout(null);
        setResizable(false);
        setLocationRelativeTo(null);
        
        ImageIcon imagenRegUsuario = new ImageIcon(getClass().getResource("/imagenes/fondo3.jpg"));

        // Creando los componentes
        lblId = new JLabel("Id:");
        lblNombre = new JLabel("Nombre:");
        lblAparterno = new JLabel("Primer apellido:");
        lblAmaterno = new JLabel("Segundo apellido:");
        lblUsuario = new JLabel("Usuario:");
        lblClave = new JLabel("Contraseña:");
        lblConfirmarClave = new JLabel("Confirmar contraseña: ");
        lblPerfil = new JLabel("Rol:");

        txtId = new JTextField();
        txtaparterno = new JTextField();
        txtNombre = new JTextField();
        txtAmarterno = new JTextField();
        txtUsuario = new JTextField();
        txtClave = new JPasswordField();
        TxtConfirmaClave = new JPasswordField();
        cmbperfil = new JComboBox<>(Perfil);

        btnRegistrar = new JButton("Registrar");
        btnCancelar = new JButton("Cancelar");
        lblFondo2 = new JLabel();
        lblFondo2.setIcon(imagenRegUsuario);
        
        
          
        // Agregar componentes
        add(lblId);
        add(lblNombre);
        add(lblAparterno);
        add(lblAmaterno);
        add(lblUsuario);
        add(lblClave);
        add(lblConfirmarClave);
        add(lblPerfil);
        add(txtId);
        add(txtaparterno);
        add(txtNombre);
        add(txtAmarterno);
        add(txtUsuario);
        add(txtClave);
        add(TxtConfirmaClave);
        add(cmbperfil);
        add(btnRegistrar);
        add(btnCancelar);
        add(lblFondo2);

        
        Font FontTitle = new Font("Century Gothic", Font.PLAIN, 16);
        // Asignar posiciones
        lblFondo2.setBounds(620, -30, 650, 600);
        
        lblId.setBounds(5, 20, 180, 25);
        txtId.setBounds(240, 20, 150, 25);
        lblId.setFont(FontTitle);
        lblId.setForeground(Color.WHITE);
        lblId.setBackground(Color.black);
        lblId.setOpaque(true);

        lblNombre.setBounds(5, 70, 180, 25);
        txtNombre.setBounds(240, 70, 150, 25);
         lblNombre.setFont(FontTitle);
         lblNombre.setForeground(Color.WHITE);
         lblNombre.setBackground(Color.black);
         lblNombre.setOpaque(true);
        

        lblAparterno.setBounds(5, 120, 180, 25);
        txtaparterno.setBounds(240, 120, 150, 25);
        
         lblAparterno.setFont(FontTitle);
         lblAparterno.setForeground(Color.WHITE);
         lblAparterno.setBackground(Color.black);
         lblAparterno.setOpaque(true);

        lblAmaterno.setBounds(5, 170, 180, 25);
        txtAmarterno.setBounds(240, 170, 150, 25);
                
         lblAmaterno.setFont(FontTitle);
         lblAmaterno.setForeground(Color.WHITE);
         lblAmaterno.setBackground(Color.black);
         lblAmaterno.setOpaque(true);        
         //cordenadas//
        lblUsuario.setBounds(410, 20, 180, 25);
        txtUsuario.setBounds(590, 20, 150, 25);
         lblUsuario.setFont(FontTitle);
         lblUsuario.setForeground(Color.WHITE);
         lblUsuario.setBackground(Color.black);
         lblUsuario.setOpaque(true);    

        lblClave.setBounds(410, 70, 180, 25);
        txtClave.setBounds(590, 70, 150, 25);
           lblClave.setFont(FontTitle);
           lblClave.setForeground(Color.WHITE);
           lblClave.setBackground(Color.black);
           lblClave.setOpaque(true);  

        lblConfirmarClave.setBounds(410, 120, 180, 25);
        TxtConfirmaClave.setBounds(590, 120, 150, 25);
           lblConfirmarClave.setFont(FontTitle);
           lblConfirmarClave.setForeground(Color.WHITE);
           lblConfirmarClave.setBackground(Color.black);
           lblConfirmarClave.setOpaque(true);  

        lblPerfil.setBounds(410, 160, 100, 25);
          lblPerfil.setFont(FontTitle);
            lblPerfil.setForeground(Color.WHITE);
            lblPerfil.setBackground(Color.black);
            lblPerfil.setOpaque(true);  
        
        cmbperfil.setBounds(590, 160, 130, 25);
          

        btnRegistrar.setBounds(80, 400, 150, 25);
        btnCancelar.setBounds(360, 400, 150, 25);
        
     

        // Configurar botones
        configurarBoton(btnRegistrar, Color.GREEN, new Color(50, 205, 50));
        configurarBoton(btnCancelar, Color.RED, new Color(255, 69, 0));

        // Listeners de los botones
        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });

        btnCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
    }

    private void configurarBoton(JButton boton, Color color, Color colorHover) {
        int radioBorde = 15;
        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Roboto", Font.PLAIN, 18));

        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));
        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));
        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));

        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(colorHover);
                boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            public void mouseExited(MouseEvent e) {
                boton.setBackground(color);
                boton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });
    }

    private void btnRegistrarActionPerformed(ActionEvent evt) {
        // Obtener los valores ingresados por el usuario
        String id = txtId.getText();
        String nombre = txtNombre.getText();
        String apellido1 = txtaparterno.getText();
        String apellido2 = txtAmarterno.getText();
        String usuario = txtUsuario.getText();
        String clave = new String(txtClave.getPassword());
        String confClave = new String(TxtConfirmaClave.getPassword());
        String perfil = (String) cmbperfil.getSelectedItem(); 

        // Validar que los campos obligatorios no estén vacíos
        if ( id.isEmpty() || nombre.isEmpty() || apellido1.isEmpty() || usuario.isEmpty() || clave.isEmpty() || confClave.isEmpty() ) {
        	JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
        		
        }else if (!clave.equals(confClave)) {
            JOptionPane.showMessageDialog(this, "Las contraseñas deben ser iguales", "Error", JOptionPane.ERROR_MESSAGE);
        	
        }else {	
            	Conexion conexionBd = new Conexion();
             try (Connection conexion = conexionBd.EstablecerConexion() ) {
                    // Consulta para insertar un nuevo usuario
                    String consulta = "INSERT INTO usuarios (Codigo, Nombre, Apaterno, Amaterno, Usuario, Contrasena, Rol) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conexion.prepareStatement(consulta)) {
                        pstmt.setString(1, id);
                        pstmt.setString(2, nombre);
                        pstmt.setString(3, apellido1);
                        pstmt.setString(4, apellido2);
                        pstmt.setString(5, usuario);
                        pstmt.setString(6, clave);
                        pstmt.setString(7, perfil);

                        // Ejecutar la consulta
                        int filasAfectadas = pstmt.executeUpdate();

                        if (filasAfectadas > 0) {
                            JOptionPane.showMessageDialog(this, "Usuario registrado con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(this, "No se pudo registrar el usuario", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al conectar a la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
                }
        	}
        }
     
        
        


  


    private void btnCancelarActionPerformed(ActionEvent evt) {
        // BRO, AQUI PUEDES HACER QUE SE LIMPIEN LAS CASILLAS 
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RegUsuarios frame = new RegUsuarios();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}


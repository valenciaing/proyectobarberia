    package conexion;

import static com.itextpdf.text.pdf.PdfFileSpecification.url;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {

    // Variables for database connection
    private Connection conectar = null;
    private Connection con;
    private final String usuario = "root";
    private final String contrasena = "root";
    private final String bd = "bdBarberia";
    private final String ip = "localhost";
    private final String puerto = "3306";

    // Connection URL with timezone information
    private final String Cadena = "jdbc:mysql://" + ip + ":" + puerto + "/" + bd + "?serverTimezone=UTC";

    // Establish the database connection
    public Connection EstablecerConexion() {
        try {
            
            // Load the JDBC driver and establish the connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            conectar = DriverManager.getConnection(Cadena, usuario, contrasena);
            // JOptionPane.showMessageDialog(null, "Conexion Establecida Exitosamente!");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al intentar la conexion: " + e.toString());
        }
        return conectar;
    }

    public Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(Cadena,usuario,contrasena);
            return con;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}

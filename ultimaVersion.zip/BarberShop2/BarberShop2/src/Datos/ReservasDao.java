/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author ADMIN
 */
public class ReservasDao {
    
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    
    public boolean RegistrarReservas(Reservas res) {
        
        String sql = "insert into reservas (Cliente,Telefono,Barbero,Servicio,FechaReserva,precio) values (?,?,?,?,?,?)";
        
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1,res.getCliente());
            ps.setString(2, res.getTelefono());
            ps.setString(3, res.getBarbero());
            ps.setString(4, res.getServicio());
            ps.setString(5, res.getHoraReserva());
            ps.setDouble(6,res.getPrecio());
            
            ps.execute();
            return true;
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;
        }
            
    }
    
    public boolean EliminarReserva(String Name) {
    // Consulta SQL para verificar si el cliente existe
    String sqlVerificarCliente = "select count(*) from reservas where Cliente = ?";
    
    // Consulta SQL para eliminar la reserva
    String sqlEliminarReserva = "delete from reservas where Cliente = ?";
    
    try {
        con = cn.getConnection();
        
     
        PreparedStatement psVerificar = con.prepareStatement(sqlVerificarCliente);
        psVerificar.setString(1, Name);
        ResultSet rs = psVerificar.executeQuery();
        
        rs.next();
        int count = rs.getInt(1);
     
        if (count > 0) {
            PreparedStatement psEliminar = con.prepareStatement(sqlEliminarReserva);
            psEliminar.setString(1, Name);
            psEliminar.execute();
            
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "El cliente no existe");
            return false;
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, e.toString());
        return false;
    } finally {
        try {
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }
}

    
    public List mostrarReservas() {
        
        List<Reservas> ListarReser = new ArrayList();
        String sql = "select * from reservas";
        
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                Reservas reserv = new Reservas();
                
                reserv.setId(rs.getInt("Id"));
                reserv.setCliente(rs.getString("Cliente"));
                reserv.setTelefono(rs.getString("Telefono"));
                reserv.setBarbero(rs.getString("Barbero"));
                reserv.setServicio(rs.getString("Servicio"));
                reserv.setHoraReserva(rs.getString("FechaReserva")); 
                reserv.setPrecio(rs.getDouble("Precio"));
                
                ListarReser.add(reserv);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        
        return ListarReser;
    }
    
    
    
}

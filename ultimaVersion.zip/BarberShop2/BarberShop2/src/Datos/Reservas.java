/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

//import java.sql.Timestamp;

/**
 *
 * @author ADMIN
 */
public class Reservas {
    private int id;
    private String cliente;
    private String telefono;
    private String barbero;
    private String servicio;
    private double precio;
    private String horaReserva;
    
    public Reservas() {
    }

    public Reservas(int id, String cliente, String telefono, String barbero, String servicio, double precio) {
        this.id = id;
        this.cliente = cliente;
        this.telefono = telefono;
        this.barbero = barbero;
        this.servicio = servicio;
        this.precio = precio;
    }

    public String getHoraReserva() {
        return horaReserva;
    }

    public void setHoraReserva(String horaReserva) {
        this.horaReserva = horaReserva;
    }

    public Reservas(String horaReserva) {
        this.horaReserva = horaReserva;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getBarbero() {
        return barbero;
    }

    public void setBarbero(String barbero) {
        this.barbero = barbero;
    }

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    
}

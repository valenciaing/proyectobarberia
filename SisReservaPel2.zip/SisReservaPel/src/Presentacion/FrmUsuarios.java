package Presentacion;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;

import Conexion.ConexionBD;

public class FrmUsuarios extends JInternalFrame {

    // Declarando los componentes
    private JLabel lblId, lblNombre, lblAparterno, lblAmaterno;
    private JLabel lblUsuario, lblClave, lblConfirmarClave, lblPerfil;
    private JTextField txtId, txtaparterno, txtNombre, txtAmarterno;
    private JTextField txtUsuario;
    private JPasswordField txtClave, TxtConfirmaClave;
    private JComboBox<String> cmbperfil;
    private JButton btnRegistrar, btnCancelar;

    private String[] Perfil = { "Administrador", "Empleado" };

    public FrmUsuarios() {

        setTitle("Usuarios");
        setSize(900, 500);
        setClosable(true);
        setIconifiable(true);
        setLayout(null);

        // Creando los componentes
        lblId = new JLabel("Id:");
        lblNombre = new JLabel("Nombre:");
        lblAparterno = new JLabel("Primer apellido:");
        lblAmaterno = new JLabel("Segundo apellido:");

        lblUsuario = new JLabel("Usuario:");
        lblClave = new JLabel("Contraseña:");
        lblConfirmarClave = new JLabel("Confirmar:");
        lblPerfil = new JLabel("Rol:");

        txtId = new JTextField();
        txtaparterno = new JTextField();
        txtNombre = new JTextField();
        txtAmarterno = new JTextField();
        txtUsuario = new JTextField();
        txtClave = new JPasswordField();
        TxtConfirmaClave = new JPasswordField();
        cmbperfil = new JComboBox<>(Perfil);

        btnRegistrar = new JButton("Registrar");
        btnCancelar = new JButton("Cancelar");

        // Agregar componentes
        add(lblId);
        add(lblNombre);
        add(lblAparterno);
        add(lblAmaterno);

        add(lblUsuario);
        add(lblClave);
        add(lblConfirmarClave);
        add(lblPerfil);

        add(txtId);
        add(txtaparterno);
        add(txtNombre);
        add(txtAmarterno);
        add(txtUsuario);
        add(txtClave);
        add(TxtConfirmaClave);
        add(cmbperfil);
        add(btnRegistrar);
        add(btnCancelar);

        // Asignar posiciones
        lblId.setBounds(90, 20, 180, 25);
        txtId.setBounds(115, 20, 100, 25);

        lblNombre.setBounds(55, 70, 180, 25);
        txtNombre.setBounds(115, 70, 150, 25);

        lblAparterno.setBounds(15, 120, 180, 25);
        txtaparterno.setBounds(115, 120, 150, 25);

        lblAmaterno.setBounds(5, 170, 180, 25);
        txtAmarterno.setBounds(115, 170, 150, 25);

        lblUsuario.setBounds(60, 220, 180, 25);
        txtUsuario.setBounds(115, 220, 150, 25);

        lblClave.setBounds(35, 270, 180, 25);
        txtClave.setBounds(115, 270, 150, 25);

        lblConfirmarClave.setBounds(10, 320, 180, 25);
        TxtConfirmaClave.setBounds(115, 320, 150, 25);

        lblPerfil.setBounds(250, 20, 100, 25);
        cmbperfil.setBounds(300, 20, 130, 25);

        btnRegistrar.setBounds(60, 400, 150, 25);
        btnCancelar.setBounds(245, 400, 150, 25);

        // Configurar botones
        configurarBoton(btnRegistrar, Color.GREEN, new Color(50, 205, 50)); // Verde y verde claro
        configurarBoton(btnCancelar, Color.RED, new Color(255, 69, 0)); // Rojo y naranja oscuro

        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });

        btnCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
    }

    // Configurar botones
    private void configurarBoton(JButton boton, Color color, Color colorHover) {
        int radioBorde = 15;
        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Roboto", Font.PLAIN, 18));

        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));
        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));
        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));

        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(colorHover);
                boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            public void mouseExited(MouseEvent e) {
                boton.setBackground(color);
                boton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });
    }

    private void btnRegistrarActionPerformed(ActionEvent evt) {
        // Obtener los valores ingresados por el usuario
        String id = txtId.getText();
        String nombre = txtNombre.getText();
        String apellido1 = txtaparterno.getText();
        String apellido2 = txtAmarterno.getText();
        String usuario = txtUsuario.getText();
        String clave = new String(txtClave.getPassword());
        String confClave = new String(TxtConfirmaClave.getPassword());
        String perfil = (String) cmbperfil.getSelectedItem(); 

        // Validar que los campos obligatorios no estén vacíos
        if ( id.isEmpty() || nombre.isEmpty() || apellido1.isEmpty() || usuario.isEmpty() || clave.isEmpty() || confClave.isEmpty() ) {
        	JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
        		
        }else if (!clave.equals(confClave)) {
            JOptionPane.showMessageDialog(this, "Las contraseñas deben ser iguales", "Error", JOptionPane.ERROR_MESSAGE);
        	
        }else {	
            	
             try (Connection conexion = ConexionBD.obtenerConexion()) {
                    // Consulta para insertar un nuevo usuario
                    String consulta = "INSERT INTO usuarios (Codigo, Nombre, Apaterno, Amaterno, Usuario, Contrasena, Rol) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conexion.prepareStatement(consulta)) {
                        pstmt.setString(1, id);
                        pstmt.setString(2, nombre);
                        pstmt.setString(3, apellido1);
                        pstmt.setString(4, apellido2);
                        pstmt.setString(5, usuario);
                        pstmt.setString(6, clave);
                        pstmt.setString(7, perfil);

                        // Ejecutar la consulta
                        int filasAfectadas = pstmt.executeUpdate();

                        if (filasAfectadas > 0) {
                            JOptionPane.showMessageDialog(this, "Usuario registrado con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(this, "No se pudo registrar el usuario", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al conectar a la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
                }
        	}
        }
     
        
        


  


    private void btnCancelarActionPerformed(ActionEvent evt) {
        // BRO, AQUI PUEDES HACER QUE SE LIMPIEN LAS CASILLAS 
    }
}

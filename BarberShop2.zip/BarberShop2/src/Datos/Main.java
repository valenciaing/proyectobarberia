/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

import Presentacion.Login;
import presentacion.Principal;

/**
 * @Creditos SebastianDevps !!
 * @author Usuario
 */
public class Main {
    
    public static void main(String[] args) {

	
	//Login miLogin = new Login();
	Principal miPrincipal = new Principal();
	   //miLogin.setVisible(true);	
		miPrincipal.setVisible(true);
	}
    
}

package Presentacion;

import conexion.Conexion;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//imports conexion
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import javax.swing.*;
import presentacion.Principal;
import presentacion.RegUsuarios;


public class Login extends JFrame {

    private JLabel lblTitulo,lblUsuario, lblClave, lblImagen;

    private JTextField txtUsuario;

    private JPasswordField txtClave;

    private JButton btnIngresar, btnRegistrar;

    public Login() {

        setTitle("Ingresando al sistema...");
        setSize(800, 550);

        // Establecer el color de fondo oscuro
        getContentPane().setBackground(Color.BLACK);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setLayout(null);
        setResizable(false);

        setLocationRelativeTo(null);

        // crear iconos por ahora no

        // crear imagen del logo de la barberia

        ImageIcon imagenLogin = new ImageIcon(getClass().getResource("/imagenes/login.png"));

        // CREAMOS COMPONENTES
        lblTitulo = new JLabel("L o g   I n");
        lblUsuario = new JLabel("Usuario:");
        txtUsuario = new JTextField();
        lblClave = new JLabel("Contraseña:");

        txtClave = new JPasswordField();

        btnIngresar = new JButton("Ingresar");

        btnRegistrar = new JButton("Registrar");

        lblImagen = new JLabel();

        // asignar el icono

        lblImagen.setIcon(imagenLogin);

        // agreguemos componentes
        
        add(lblTitulo);
        add(lblUsuario);
        add(txtUsuario);
        add(lblClave);
        add(txtClave);
        add(btnIngresar);
        add(btnRegistrar);
        add(lblImagen);

        // TIPO LETRA Y TAMAÑO

        Font buttonFont = new Font("Roboto", Font.PLAIN, 16);
        Font FontTitle = new Font("Century Gothic", Font.PLAIN, 25);

        // asignar posiciones

        lblImagen.setBounds(-80, 0, 550, 530);
        
        lblTitulo.setBounds(580, 80, 120, 30);
        lblTitulo.setFont(FontTitle);
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setBackground(Color.black);
        lblTitulo.setOpaque(true);
        
        lblUsuario.setBounds(500, 190, 120, 23);
        lblUsuario.setFont(buttonFont);
        lblUsuario.setForeground(Color.WHITE);
        lblUsuario.setBackground(Color.black);
        lblUsuario.setOpaque(true);
        txtUsuario.setBounds(580, 190, 170, 25);

        lblClave.setBounds(480, 250, 100, 25);
        lblClave.setFont(buttonFont);
        lblClave.setForeground(Color.WHITE);
        lblClave.setBackground(Color.black);
        lblClave.setOpaque(true);
        txtClave.setBounds(580, 250, 170, 25);

        btnIngresar.setBounds(500, 350, 100, 25);
        btnRegistrar.setBounds(630, 350, 100, 25);

        // Configurar botones
        configurarBoton(btnIngresar, Color.GREEN, new Color(50, 205, 50)); // Verde y verde claro
        configurarBoton(btnRegistrar, Color.BLUE, new Color(68, 128, 218)); // Azul y Azul Claro

        btnIngresar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                btnIngresarActionPerformed(evt);

            }

        });

        btnRegistrar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }

        });
    }

    private void configurarBoton(JButton boton, Color color, Color colorHover) {
        // Establecer el radio del borde
        int radioBorde = 15;
        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Roboto", Font.PLAIN, 18));
        
     // Establecer el radio del borde
        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));
        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));
        boton.setBorder(BorderFactory.createLineBorder(color, 2, true));

        
        // Añadir efecto hover y cambio de cursor
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(colorHover);
                boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            public void mouseExited(MouseEvent e) {
                boton.setBackground(color);
                boton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });
    }

    //-------------------------------   CONEXION   ------------------------------------
    //------------------------------------------------------------------------------
    public void btnIngresarActionPerformed(ActionEvent evt) {
        // Obtener las credenciales ingresadas por el usuario
        String usuario = txtUsuario.getText();
        String clave = new String(txtClave.getPassword());

        // Intentar establecer la conexión
        Conexion ConexionBd = new Conexion();
        try (Connection conexion = (Connection) ConexionBd.EstablecerConexion()) {
            // Consulta para verificar las credenciales
            String consulta = "SELECT * FROM usuarios WHERE Usuario = ? AND Contrasena = ?";
            try (PreparedStatement pstmt = conexion.prepareStatement(consulta)) {
                pstmt.setString(1, usuario);
                pstmt.setString(2, clave);

                // Ejecutar la consulta
                try (ResultSet rs = pstmt.executeQuery()) {
                    // Verificar si se encontraron resultados (credenciales válidas)
                    if (rs.next()) {
                        // Credenciales válidas, abrir la ventana principal
                        Principal  miPrincipal = new Principal();
                        miPrincipal.setLocationRelativeTo(null);
                        miPrincipal.setVisible(true);
                        this.dispose();
                    } else {
                        // Credenciales inválidas, mostrar mensaje de error
                        JOptionPane.showMessageDialog(this, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al conectar a la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void btnCancelarActionPerformed(ActionEvent evt) {
        RegUsuarios FormUsuarios = new RegUsuarios();
        FormUsuarios.setVisible(true);

    }
}
